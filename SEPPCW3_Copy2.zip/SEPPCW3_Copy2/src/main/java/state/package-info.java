/**
 * The state package contains all the classes that hold application state, like bookings, events, sponsorship requests,
 * and users.
 */
package state;