/**
 * The external package contains interfaces for the external EntertainmentProviderSystem and
 * PaymentSystem.
 */
package external;