/**
 * The command package contains all the commands that implement the ICommand interface.
 * This makes use of the Command design pattern.
 */
package command;