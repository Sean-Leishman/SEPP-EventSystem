/**
 * The logging package contains the singleton Logger that logs events from anywhere in the application
 */
package logging;