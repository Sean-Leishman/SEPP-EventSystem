package model;

public enum EventStatus {
    ACTIVE, CANCELLED
}