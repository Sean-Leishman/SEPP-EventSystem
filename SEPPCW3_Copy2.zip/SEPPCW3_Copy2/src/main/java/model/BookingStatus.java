package model;

public enum BookingStatus {
    Active, CancelledByConsumer, CancelledByProvider, PaymentFailed
}