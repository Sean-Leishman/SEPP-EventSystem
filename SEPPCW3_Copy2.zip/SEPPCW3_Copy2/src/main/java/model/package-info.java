/**
 * The model package contains data structures corresponding to the classes and actors in the assignment specification
 */
package model;